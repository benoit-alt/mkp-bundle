
from typing import List, Tuple
from collections import defaultdict
from datetime import datetime

def _to_dt(s: str):
    try:
        return datetime.fromisoformat(s.replace("Z","+00:00"))
    except Exception:
        try:
            return datetime.strptime(s, "%Y-%m-%d")
        except Exception:
            return None

def _conf_to_float(v):
    try:
        return float(v)
    except Exception:
        m = {"low":0.3,"medium":0.6,"high":0.9}
        return m.get(str(v).strip().lower(), 0.0)

def resolve_conflicts(claims: List[dict], core_module_id: str="core") -> Tuple[List[dict], List[dict]]:
    by_sp = defaultdict(list)
    for c in claims:
        key = (c.get("subject",""), c.get("predicate",""))
        by_sp[key].append(c)

    conflict_index = []
    conflict_log = []

    for (subject, predicate), grp in by_sp.items():
        values = defaultdict(list)
        for c in grp:
            values[c.get("object","")].append(c)

        if len(values) <= 1:
            continue

        core_claims = [c for c in grp if c.get("source_module","") == core_module_id]
        if core_claims:
            chosen_val = core_claims[0].get("object","")
            for val, rows in values.items():
                if val != chosen_val:
                    conflict_log.append({
                        "entity_urn": subject,
                        "field": predicate,
                        "winning_value": chosen_val,
                        "losing_value": val,
                        "resolution_rule": "core_immutable",
                        "winning_source_module": core_module_id
                    })
            continue

        def freshness(c):
            dt = _to_dt(c.get("observed_at","")) or _to_dt(c.get("last_updated",""))
            return dt or datetime.min
        freshest = max(grp, key=freshness)
        fresh_val = freshest.get("object","")
        freshest_dt = freshness(freshest)
        rivals = [c for c in grp if freshness(c)==freshest_dt and c.get("object","")!=fresh_val]
        if rivals:
            all_tied = [freshest] + rivals
            winner = max(all_tied, key=lambda c: _conf_to_float(c.get("confidence",0)))
            win_val = winner.get("object",""); win_mod = winner.get("source_module","")
            for c in all_tied:
                if c is not winner:
                    conflict_log.append({
                        "entity_urn": subject,
                        "field": predicate,
                        "winning_value": win_val,
                        "losing_value": c.get("object",""),
                        "resolution_rule": "prefer_higher_source_confidence",
                        "winning_source_module": win_mod
                    })
        else:
            for c in grp:
                if c.get("object","") != fresh_val:
                    conflict_log.append({
                        "entity_urn": subject,
                        "field": predicate,
                        "winning_value": fresh_val,
                        "losing_value": c.get("object",""),
                        "resolution_rule": "prefer_fresh",
                        "winning_source_module": freshest.get("source_module","")
                    })

        conflict_index.append({
            "subject": subject,
            "predicate": predicate,
            "values": list(values.keys())
        })

    return conflict_index, conflict_log
