
import csv
from typing import Set
from pathlib import Path

DEFAULT_12 = {
    "IS_A","USES","PROVIDES","MITIGATES","EXPLOITS","TARGETS",
    "LOCATED_IN","AFFILIATED_WITH","BLOCKS","REQUIRES","CONFLICTS_WITH","RELATED_TO"
}

def load_predicates(core_dir: Path) -> Set[str]:
    pred_file = core_dir / "graph" / "predicates.csv"
    if pred_file.exists():
        s = set()
        with pred_file.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                pid = (row.get("id") or row.get("label") or "").strip()
                if pid:
                    s.add(pid)
        return s
    return set(DEFAULT_12)
