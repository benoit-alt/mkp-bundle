
import re

CORE_RE = re.compile(r"^urn:entity:([a-z0-9_]+):([a-z0-9_]+)$")
MODULE_RE = re.compile(r"^urn:entity:([a-z0-9_]+):([a-z0-9_]+):([a-z0-9_]+)$")
ANY_RE = re.compile(r"^urn:entity:([a-z0-9_]+):([a-z0-9_]+)(?::([a-z0-9_]+))?$")

def is_core_urn(s: str) -> bool:
    return bool(CORE_RE.match(s or ""))

def is_module_urn(s: str) -> bool:
    return bool(MODULE_RE.match(s or ""))

def is_entity_urn(s: str) -> bool:
    return bool(ANY_RE.match(s or ""))
