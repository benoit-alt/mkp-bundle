
from pathlib import Path
from typing import Dict, Any
import json

def _parse_simple_yaml(text: str) -> Dict[str, Any]:
    data = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        k, v = line.split(":", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        # simple list support: [a,b]
        if v.startswith("[") and v.endswith("]"):
            inner = v.strip("[]").strip()
            items = [x.strip().strip('"').strip("'") for x in inner.split(",") if x.strip()]
            data[k] = items
        else:
            data[k] = v
    return data

def load_manifest(dir_path: Path):
    y = dir_path / "module.yaml"
    if y.exists():
        t = y.read_text(encoding="utf-8")
        try:
            return json.loads(t)
        except Exception:
            return _parse_simple_yaml(t)
    return {"module_id": dir_path.name, "namespace": dir_path.name, "version": "0.0.0", "compatible_core": ">=1.0.0"}
