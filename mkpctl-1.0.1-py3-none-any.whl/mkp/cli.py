
import argparse
from pathlib import Path
from .loader import load
from .predicates import load_predicates
from .validate import validate_module, validate_core
from .manifest import load_manifest
from . import __version__
import sys
import csv
import os
import json

def _write(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")

def _exit_class(code: int) -> str:
    """Map an exit code to its SPEC-003 exit_class string."""
    if code == 0: return "success"
    if 21 <= code <= 25: return "validation"
    if 31 <= code <= 32: return "load"
    if 41 <= code <= 42: return "helper"
    return "internal"

def cmd_load(args):
    core = Path(args.core).resolve()
    mods = [Path(p).resolve() for p in (args.modules or [])]
    out = Path(args.out).resolve()

    exit_code = 0
    res = None
    try:
        write_sqlite = (not args.no_sqlite) or getattr(args, 'write_sqlite', False)
        res = load(core, mods, out,
                    strict_predicates=args.strict_predicates,
                    write_sqlite_db=write_sqlite)
        print("Aggregated:", res, file=sys.stderr)
    except RuntimeError as exc:
        msg = str(exc)
        print(f"ERROR: {msg}", file=sys.stderr)
        if "validation failed" in msg:
            exit_code = _validate_exit_code(msg)
        else:
            exit_code = 31
    except Exception as exc:
        print(f"ERROR (internal): {exc}", file=sys.stderr)
        exit_code = 1

    if getattr(args, 'json_summary', False):
        summary = {
            "schema_version": "mkpctl.summary.v1",
            "command": "load",
            "exit_code": exit_code,
            "exit_class": _exit_class(exit_code),
            "kb_root": str(core.parent),
            "core_dirs": [str(core)],
            "module_dirs": [str(m) for m in mods],
            "aggregated_dir": str(out),
            "counts": {
                "entities": res["entities"] if res else 0,
                "relationships": res["relationships"] if res else 0,
                "claims": res["claims"] if res else 0,
                "conflicts": res["conflicts"] if res else 0,
            },
            "top_predicates": res.get("top_predicates", []) if res else [],
        }
        print(json.dumps(summary, indent=2))

    sys.exit(exit_code)

def _validate_exit_code(msg: str) -> int:
    """Derive SPEC-003 exit code from a validation error message."""
    if "missing columns" in msg:
        return 21   # schema
    if "Invalid URN" in msg:
        return 22   # URN
    if "Predicate not allowed" in msg:
        return 23   # predicate
    if "Dangling reference" in msg:
        return 24   # dangling ref
    if "mutate Core" in msg:
        return 25   # dependency
    return 21       # default to schema

def cmd_validate(args):
    core = Path(args.core).resolve()
    preds = load_predicates(core)
    ok, msg = validate_core(core, preds, strict_predicates=args.strict_predicates)
    if not ok:
        print("Core validation FAILED:", msg); sys.exit(_validate_exit_code(msg))
    print("Core validation OK.")
    for p in (args.modules or []):
        md = Path(p).resolve()
        core_ids = set()
        with (core / "graph" / "entities.csv").open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                core_ids.add(row["id"])
        ok, msg = validate_module(md, core_ids, preds, strict_predicates=args.strict_predicates)
        if not ok:
            print(f"Module validation FAILED ({md.name}):", msg); sys.exit(_validate_exit_code(msg))
        print(f"Module validation OK: {md.name}")

def _write_csv(path: Path, headers, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(headers)
        for r in rows:
            w.writerow(r)

def _kb_core_skeleton(root: Path):
    core = root / "00_Core_System"
    # module.yaml
    _write(core / "module.yaml", f"""module_id: core
namespace: core
version: {__version__}
compatible_core: "self"
depends_on: []
last_updated: 2026-02-01
maintainers: Core Team
license: CC-BY-4.0
""")
    # predicates.csv
    preds = ["IS_A","USES","PROVIDES","MITIGATES","EXPLOITS","TARGETS","LOCATED_IN","AFFILIATED_WITH","BLOCKS","REQUIRES","CONFLICTS_WITH","RELATED_TO"]
    _write_csv(core / "graph" / "predicates.csv", ["id","label","description"], [(p,p,"") for p in preds])
    # entities.csv
    _write_csv(core / "graph" / "entities.csv", ["id","type","name","description"], [
        ["urn:entity:payment:bitcoin","Payment_Method","Bitcoin","Cryptocurrency"]
    ])
    # relationships.csv
    _write_csv(core / "graph" / "relationships.csv", ["source_id","relation","target_id"], [
        # keep empty or minimal
    ])
    # evidence/timeline/sources (optional skeleton)
    _write_csv(core / "evidence" / "claims.csv", ["claim_id","subject","predicate","object","source_id","observed_at","confidence"], [])
    _write_csv(core / "evidence" / "sources.csv", ["source_id","title","publisher","published_at"], [])
    _write_csv(core / "evidence" / "timeline.csv", ["date","event"], [])
    _write(core / "narrative" / "privacy_report_structured.md", "# Core Narrative\n\nCore ontology and definitions.")

def _kb_dw_module_skeleton(root: Path):
    dw = root / "01_Module_DarkWeb"
    _write(dw / "module.yaml", f"""module_id: darkweb
namespace: darkweb
version: 1.0.0
compatible_core: ">=1.0.0, <2.0.0"
depends_on: []
last_updated: 2026-01-15
maintainers: DW Team
license: CC-BY-4.0
""")
    _write_csv(dw / "graph" / "entities.csv", ["id","type","name","description"], [
        ["urn:entity:darkweb:market:hydra","Marketplace","Hydra","Large RU-language darknet market"],
        ["urn:entity:darkweb:actor:darkoverlord","Threat_Actor","The Dark Overlord","Ransomware/extortion group"],
        ["urn:entity:darkweb:service:escrow","Service","Escrow Service","Marketplace escrow capability"],
    ])
    _write_csv(dw / "graph" / "relationships.csv", ["source_id","relation","target_id"], [
        ["urn:entity:darkweb:market:hydra","PROVIDES","urn:entity:darkweb:service:escrow"],
        ["urn:entity:darkweb:service:escrow","RELATED_TO","urn:entity:payment:bitcoin"],
        ["urn:entity:darkweb:actor:darkoverlord","AFFILIATED_WITH","urn:entity:darkweb:market:hydra"],
    ])
    _write_csv(dw / "evidence" / "claims.csv", ["claim_id","subject","predicate","object","source_id","observed_at","confidence"], [
        ["DW-CLM-1","urn:entity:darkweb:market:hydra","PROVIDES","Escrow","SRC-1","2021-11-01T00:00:00Z","0.7"],
        ["DW-CLM-2","urn:entity:darkweb:market:hydra","LOCATED_IN","Russia","SRC-2","2022-04-05T00:00:00Z","0.6"],
    ])
    _write_csv(dw / "evidence" / "sources.csv", ["source_id","title","publisher","published_at"], [
        ["SRC-1","DW Report A","Analyst A","2021-11-10"],
        ["SRC-2","DW Report B","Analyst B","2022-04-10"],
    ])
    _write_csv(dw / "evidence" / "timeline.csv", ["date","event"], [
        ["2021-01-01","Hydra growth"],
        ["2022-04-05","Hydra seized"],
    ])
    _write_csv(dw / "conflict_resolution" / "conflicts.csv", ["dispute_id","urn","aspect","claim_id","stance","source_id","observed_at","last_updated","notes"], [
        ["DW-0001","urn:entity:darkweb:market:hydra","attribute:market_share","DW-CLM-3","refutes","SRC-3","2021-11-01","2026-01-15","Market share disputed"],
    ])
    _write(dw / "narrative" / "PACKET.md", "# Dark Web Packet\n\nHydra overview and related entities.")
    _write_csv(dw / "labels_to_urn.csv", ["Label","URN"], [
        ["Hydra Market","urn:entity:darkweb:market:hydra"],
        ["TDO","urn:entity:darkweb:actor:darkoverlord"],
    ])

def cmd_demo(args):
    root = Path(args.out).resolve()
    if root.exists() and any(root.iterdir()):
        print(f"Refusing to write into non-empty directory: {root}", file=sys.stderr)
        sys.exit(4)
    (root).mkdir(parents=True, exist_ok=True)
    _kb_core_skeleton(root)
    _kb_dw_module_skeleton(root)
    # Validate and Load
    agg = root / "aggregated"
    from .loader import load
    res = load(root / "00_Core_System", [root / "01_Module_DarkWeb"], agg, strict_predicates=True, write_sqlite_db=True)
    print("Demo built. Aggregated:", res)
    print("KB root:", root)
    print("Aggregated outputs:", agg)

def cmd_build_labels(args):
    root = Path(args.root).resolve()
    out = Path(args.out).resolve()
    pairs = set()

    def harvest(p: Path):
        if not p.exists(): return
        with p.open(newline="", encoding="utf-8") as f:
            r = csv.DictReader(f)
            for row in r:
                label = (row.get("Label") or "").strip()
                urn = (row.get("URN") or "").strip()
                if label and urn and not label.startswith("urn:"):
                    pairs.add((label, urn))

    harvest(root / "00_Core_System" / "labels_to_urn.csv")
    for mod_dir in sorted(root.glob("[0-9][0-9]_Module_*")):
        harvest(mod_dir / "labels_to_urn.csv")

    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Label","URN"])
        for label, urn in sorted(pairs, key=lambda x: (x[1], x[0].lower())):
            w.writerow([label, urn])
    print("Merged labels written to:", out)

def main(argv=None):
    p = argparse.ArgumentParser(prog="mkpctl", description="Modular Knowledge Platform CLI")
    p.add_argument("--version", action="version", version=f"mkpctl {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    pload = sub.add_parser("load", help="Load Core + Modules and build aggregated outputs")
    pload.add_argument("core")
    pload.add_argument("modules", nargs="*")
    pload.add_argument("--out", required=True)
    pload.add_argument("--strict-predicates", action="store_true", default=True)
    pload.add_argument("--no-sqlite", action="store_true")
    pload.add_argument("--write-sqlite", action="store_true", default=False,
                        help="Explicitly enable SQLite output (default: on unless --no-sqlite)")
    pload.add_argument("--json-summary", action="store_true", default=False,
                        help="Emit SPEC-003 JSON summary to stdout after load")
    pload.set_defaults(func=cmd_load)

    pval = sub.add_parser("validate", help="Validate Core and Modules")
    pval.add_argument("core")
    pval.add_argument("modules", nargs="*")
    pval.add_argument("--strict-predicates", action="store_true", default=True)
    pval.set_defaults(func=cmd_validate)

    plab = sub.add_parser("build-labels", help="Merge labels_to_urn lookups")
    plab.add_argument("--root", required=True)
    plab.add_argument("--out", required=True)
    plab.set_defaults(func=cmd_build_labels)

    pdemo = sub.add_parser("demo", help="Generate a demo KB (Core + DarkWeb) and aggregate it")
    pdemo.add_argument("out", help="Target directory for the demo KB")
    pdemo.set_defaults(func=cmd_demo)

    args = p.parse_args(argv)
    return args.func(args)

def cli():
    return main()

if __name__ == "__main__":
    cli()
