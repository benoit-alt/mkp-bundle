
from pathlib import Path
from typing import List
import csv
from .manifest import load_manifest
from .predicates import load_predicates
from .validate import validate_core, validate_module
from .index import load_entities_csv, load_relationships_csv, write_sqlite
from .conflicts import resolve_conflicts

def topo_sort_by_dependencies(mod_dirs: List[Path]) -> List[Path]:
    return mod_dirs

def read_claims(dir_path: Path) -> List[dict]:
    p = dir_path / "evidence" / "claims.csv"
    if not p.exists(): return []
    with p.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def read_conflicts(dir_path: Path) -> List[dict]:
    p = dir_path / "conflict_resolution" / "conflicts.csv"
    if not p.exists(): return []
    with p.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def load(core_dir: Path, module_dirs: List[Path], out_dir: Path, strict_predicates: bool=True, write_sqlite_db: bool=True):
    out_dir.mkdir(parents=True, exist_ok=True)

    predicates = load_predicates(core_dir)
    ok, msg = validate_core(core_dir, predicates, strict_predicates=strict_predicates)
    if not ok:
        raise RuntimeError(f"Core validation failed: {msg}")

    core_entities = load_entities_csv(core_dir / "graph" / "entities.csv")
    core_ids = {e["id"] for e in core_entities}
    core_rels = load_relationships_csv(core_dir / "graph" / "relationships.csv")
    for r in core_rels:
        r["source_module"] = "core"

    core_claims = read_claims(core_dir)
    for c in core_claims:
        c["source_module"] = "core"
    core_conflicts = read_conflicts(core_dir)
    for x in core_conflicts:
        x["source_module"] = "core"

    ordered = topo_sort_by_dependencies(module_dirs)
    mod_entities = []
    mod_rels = []
    mod_claims = []
    mod_conflicts = []

    for md in ordered:
        manifest = load_manifest(md)
        ok, msg = validate_module(md, core_ids, predicates, strict_predicates=strict_predicates)
        if not ok:
            raise RuntimeError(f"Module validation failed ({md.name}): {msg}")
        ents = load_entities_csv(md / "graph" / "entities.csv")
        for e in ents: e["source_module"] = manifest.get("module_id", md.name)
        rels = load_relationships_csv(md / "graph" / "relationships.csv")
        for r in rels: r["source_module"] = manifest.get("module_id", md.name)
        claims = read_claims(md)
        for c in claims: c["source_module"] = manifest.get("module_id", md.name)
        confs = read_conflicts(md)
        for x in confs: x["source_module"] = manifest.get("module_id", md.name)
        mod_entities.extend(ents); mod_rels.extend(rels); mod_claims.extend(claims); mod_conflicts.extend(confs)

    all_entities = [dict(e, **{"source_module":"core"}) for e in core_entities] + mod_entities
    all_rels = core_rels + mod_rels
    all_claims = core_claims + mod_claims
    all_conflicts = core_conflicts + mod_conflicts

    conflict_index, conflict_log = resolve_conflicts(all_claims, core_module_id="core")

    import pandas as pd
    pd.DataFrame(all_entities).to_csv(out_dir / "entities.csv", index=False)
    pd.DataFrame(all_rels).to_csv(out_dir / "relationships.csv", index=False)
    pd.DataFrame(all_claims).to_csv(out_dir / "claims.csv", index=False)
    pd.DataFrame(all_conflicts).to_csv(out_dir / "conflicts.csv", index=False)
    pd.DataFrame(conflict_index).to_csv(out_dir / "conflict_index.csv", index=False)
    pd.DataFrame(conflict_log, columns=["entity_urn","field","winning_value","losing_value","resolution_rule","winning_source_module"]).to_csv(out_dir / "conflict_log.csv", index=False)

    if write_sqlite_db:
        write_sqlite(out_dir / "registry.sqlite", all_entities, all_rels, all_claims, all_conflicts)

    # Compute top predicates (top 3 by edge count, stable sort by name)
    from collections import Counter
    pred_counts = Counter(r["relation"] for r in all_rels)
    top_predicates = [
        {"predicate": p, "edge_count": c}
        for p, c in sorted(pred_counts.items(), key=lambda x: (-x[1], x[0]))[:3]
    ]

    return {
        "entities": len(all_entities),
        "relationships": len(all_rels),
        "claims": len(all_claims),
        "conflicts": len(all_conflicts),
        "conflict_index": len(conflict_index),
        "conflict_log": len(conflict_log),
        "top_predicates": top_predicates,
    }
