
from pathlib import Path
from typing import Dict, Any, Set, Tuple
import csv
from .urns import is_entity_urn

REQ_ENT = ["id","type","name","description"]
REQ_REL = ["source_id","relation","target_id"]

def _check_headers(path: Path, required: list) -> Tuple[bool, str]:
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        try:
            headers = next(reader)
        except StopIteration:
            return False, f"{path.name} is empty"
    missing = [h for h in required if h not in headers]
    if missing:
        return False, f"{path.name}: missing columns {missing}"
    return True, ""

def validate_core(core_dir: Path, predicates: Set[str], strict_predicates: bool=True) -> Tuple[bool, str]:
    ent = core_dir / "graph" / "entities.csv"
    rel = core_dir / "graph" / "relationships.csv"
    ok, msg = _check_headers(ent, REQ_ENT)
    if not ok: return ok, msg
    ok, msg = _check_headers(rel, REQ_REL)
    if not ok: return ok, msg

    with ent.open(newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if not is_entity_urn(row["id"]): return False, f"Invalid URN in entities: {row['id']}"

    with rel.open(newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if strict_predicates and row["relation"] not in predicates:
                return False, f"Predicate not allowed (core): {row['relation']}"
            if not is_entity_urn(row["source_id"]) or not is_entity_urn(row["target_id"]):
                return False, f"Invalid URN in relationships: {row}"
    return True, ""

def validate_module(mod_dir: Path, core_ids: Set[str], predicates: Set[str], strict_predicates: bool=True) -> Tuple[bool, str]:
    ent = mod_dir / "graph" / "entities.csv"
    rel = mod_dir / "graph" / "relationships.csv"
    ok, msg = _check_headers(ent, REQ_ENT)
    if not ok: return ok, msg
    ok, msg = _check_headers(rel, REQ_REL)
    if not ok: return ok, msg

    module_ids = set()
    with ent.open(newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            eid = row["id"]
            if not is_entity_urn(eid): return False, f"Invalid URN in module entities: {eid}"
            if eid in core_ids: return False, f"Module attempts to mutate Core entity: {eid}"
            module_ids.add(eid)

    with rel.open(newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if strict_predicates and row["relation"] not in predicates:
                return False, f"Predicate not allowed (module): {row['relation']}"
            s = row["source_id"]; t = row["target_id"]
            if not is_entity_urn(s) or not is_entity_urn(t):
                return False, f"Invalid URN in module relationships: {row}"
            if (s not in core_ids) and (s not in module_ids):
                return False, f"Dangling reference (source): {s}"
            if (t not in core_ids) and (t not in module_ids):
                return False, f"Dangling reference (target): {t}"
    return True, ""
