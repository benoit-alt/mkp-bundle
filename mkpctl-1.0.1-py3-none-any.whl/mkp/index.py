
from typing import List
from pathlib import Path
import csv
import sqlite3

def _parse_conf(v):
    if v is None:
        return 0.0
    s = str(v).strip().lower()
    try:
        return float(s)
    except Exception:
        mapping = {"low":0.3,"medium":0.6,"high":0.9}
        return mapping.get(s, 0.0)

def load_entities_csv(path: Path) -> List[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def load_relationships_csv(path: Path) -> List[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def write_sqlite(db_path: Path, entities: List[dict], relationships: List[dict], claims: List[dict], conflicts: List[dict]):
    if db_path.exists():
        db_path.unlink()
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    cur.execute("CREATE TABLE entities (id TEXT PRIMARY KEY, type TEXT, name TEXT, description TEXT, source_module TEXT)")
    cur.execute("CREATE TABLE relationships (source_id TEXT, relation TEXT, target_id TEXT, source_module TEXT)")
    cur.execute("CREATE TABLE claims (claim_id TEXT, subject TEXT, predicate TEXT, object TEXT, source_id TEXT, observed_at TEXT, confidence REAL, source_module TEXT)")
    cur.execute("CREATE TABLE conflicts (dispute_id TEXT, urn TEXT, aspect TEXT, claim_id TEXT, stance TEXT, observed_at TEXT, last_updated TEXT, notes TEXT, source_module TEXT)")

    cur.executemany("INSERT INTO entities VALUES (?,?,?,?,?)", [(e['id'], e.get('type',''), e.get('name',''), e.get('description',''), e.get('source_module','')) for e in entities])
    cur.executemany("INSERT INTO relationships VALUES (?,?,?,?)", [(r['source_id'], r['relation'], r['target_id'], r.get('source_module','')) for r in relationships])
    cur.executemany("INSERT INTO claims VALUES (?,?,?,?,?,?,?,?)", [(c.get('claim_id',''), c.get('subject',''), c.get('predicate',''), c.get('object',''), c.get('source_id',''), c.get('observed_at',''), _parse_conf(c.get('confidence','')), c.get('source_module','')) for c in claims])
    cur.executemany("INSERT INTO conflicts VALUES (?,?,?,?,?,?,?,?,?)", [(x.get('dispute_id',''), x.get('urn',''), x.get('aspect',''), x.get('claim_id',''), x.get('stance',''), x.get('observed_at',''), x.get('last_updated',''), x.get('notes',''), x.get('source_module','')) for x in conflicts])

    conn.commit()
    conn.close()
